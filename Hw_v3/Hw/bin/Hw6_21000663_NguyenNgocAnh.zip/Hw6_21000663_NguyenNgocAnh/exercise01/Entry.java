package Hw6_21000663_NguyenNgocAnh.exercise01;

public interface Entry <K, E> {
    K getKey();
    E getValue();
}
