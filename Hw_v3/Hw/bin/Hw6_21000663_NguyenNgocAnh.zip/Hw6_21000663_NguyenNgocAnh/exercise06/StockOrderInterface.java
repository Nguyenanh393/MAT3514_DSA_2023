package Hw6_21000663_NguyenNgocAnh.exercise06;

public interface StockOrderInterface {
    public int getStockCode();
    public int getQuantity();
    public int getPrice();
    public String getStatus();
    public void setQuantity(int quantity);
}
