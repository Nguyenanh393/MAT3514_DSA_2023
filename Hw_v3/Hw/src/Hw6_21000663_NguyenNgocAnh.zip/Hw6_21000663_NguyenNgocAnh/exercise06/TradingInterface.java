package Hw6_21000663_NguyenNgocAnh.exercise06;

public interface TradingInterface {
    public void addOrder(StockOrder order);
    public void processOrder();
}
